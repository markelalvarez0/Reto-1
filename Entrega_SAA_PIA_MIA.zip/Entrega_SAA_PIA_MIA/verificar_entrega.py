"""Comprueba los archivos entregados sin ejecutar el modelo ni los servicios."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
manifest = json.loads((root / 'MANIFIESTO_ENTREGA.json').read_text(encoding='utf-8'))
errors = []
for entry in manifest['archivos']:
    path = root / entry['ruta']
    if not path.resolve().is_relative_to(root) or path.is_symlink():
        errors.append(entry['ruta'] + ': ruta no valida')
    elif not path.is_file():
        errors.append(entry['ruta'] + ': archivo ausente')
    elif hashlib.sha256(path.read_bytes()).hexdigest() != entry['sha256']:
        errors.append(entry['ruta'] + ': contenido modificado')
if errors:
    print('\n'.join(errors))
    raise SystemExit(1)
print(f"OK: {len(manifest['archivos'])} archivos verificados. No se ha ejecutado el modelo.")
